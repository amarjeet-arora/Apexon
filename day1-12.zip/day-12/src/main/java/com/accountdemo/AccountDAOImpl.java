package com.accountdemo;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class AccountDAOImpl implements AccountDAO{
	
	Map<String, Account> hm= new HashMap<String, Account>();

	@Override
	public void createAccount(Account account) {
		if (hm.containsKey(account.getAccNo())) {
			throw new IllegalArgumentException("account " + account.getAccNo() + " already exist");
		}
		 hm.put(account.getAccNo(), new Account(account));
		
	}

	@Override
	public List<Account> getAllAccounts() {
		 List<Account> allAcc= new ArrayList<Account>();
		 for (Account account : hm.values())
			 allAcc.add(new Account(account));
		 return allAcc;
	}

	@Override
	public Account getAccount(String account) {
		Account acc= hm.get(account);
		return new Account(acc);
		 
	}

	@Override
	public void updateAccount(Account account) {
		if (!hm.containsKey(account.getAccNo())) {
			throw new IllegalArgumentException("account " + account.getAccNo() + " doesnt exist");
		}
		 hm.put(account.getAccNo(), new Account(account));
		
	}

}
