package com.accountdemo;

import java.util.List;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class ClienntMain {

	public static void main(String[] args) {
		
		ApplicationContext ctx= new ClassPathXmlApplicationContext("beans.xml");
		
		Account adam=ctx.getBean("adamAccount",Account.class);
		Account julia=ctx.getBean("juliaAccount",Account.class);
		AccountDAO ac= ctx.getBean("service",AccountDAO.class);
		
		ac.createAccount(adam);
		ac.createAccount(julia);
		
		List<Account> accounts=ac.getAllAccounts();
		for(Account acs: accounts) {
			System.out.println(acs);
		}
		

	}

}
