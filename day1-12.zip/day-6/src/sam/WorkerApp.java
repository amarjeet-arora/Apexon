package sam;

public class WorkerApp {
	
	
	public static void execute(SamDemo demo) {
		demo.doSomeWork();
	}

	public static void main(String[] args) {
		//without lambda
		execute(new SamDemo() {
			@Override
			public void doSomeWork() {
				System.out.println("lets do something .....");
				
			}
		});
		//with lambda
		execute(()-> System.out.println("do some awesome work"));
	}
}
