package streamdemo;

import java.util.List;

public class RosterMain {

	public static void main(String[] args) {
		//prints all members contained in the collection roster 
        List<Person> data=Person.createRoster();
		data.stream().forEach(e -> System.out.println(e.getName()));
		
		
		//print male members
		
		 List<Person> printMaleMembers=Person.createRoster();
		 
		 printMaleMembers.stream().filter(e -> e.getGender() == Person.Sex.MALE)
		 .forEach(e -> System.out.println("Male Members " + e.getName()));

	//calculates the avg age of all female members
		 double avg=data.stream()
				 .filter(p ->p.getGender() == Person.Sex.MALE)
				 .mapToInt(Person :: getAge)
				 .average()
				 .getAsDouble();
		 System.out.println(avg);
		//calculate the sum of all members inn roster
		 
		//return the new sorted list of all members contained in the collection roster who are male
	}

}
