package streamdemo;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

public class StreamOperations {

	public static void main(String[] args) {
		 ArrayList<String> names= new ArrayList<String>();
		 
		 names.add("Amit");
		 names.add("adam");
		 names.add("sam");
		 names.add("john");
		 names.add("sanya");
		 names.add("andy");
			/*
			 * //print the names starts with char A names.stream().filter((s) ->
			 * s.startsWith("a")) .forEach(System.out::println);
			 * 
			 * //print the names starts with char A and convert into uppercase
			 * names.stream().filter((s) -> s.startsWith("s")) .map(String ::
			 * toUpperCase).forEach(System.out::println);
			 * 
			 * 
			 * 
			 * //print the names starts with char A and convert into uppercase and sort it
			 * names.stream().sorted().filter((s) -> s.startsWith("s")) .map(String ::
			 * toUpperCase).forEach(System.out::println);
			 * 
			 * //print the names starts with char A and convert into uppercase and sort it
			 * and return another list List<String> data=names.stream().sorted().map(String
			 * :: toUpperCase).collect(Collectors.toList()); System.out.println(data);
			 */
		 
		 
		 boolean matchResult=names.stream().noneMatch((s)-> s.startsWith("b"));
		 System.out.println(matchResult);
		 
		 
		 
	}
	

}
