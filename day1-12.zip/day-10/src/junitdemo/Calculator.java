package junitdemo;

public class Calculator {
	
	public int add(int a,int b) {
		return a+b;
	}
	public int mul(int a,int b) {
		return a*b;
	}

}
