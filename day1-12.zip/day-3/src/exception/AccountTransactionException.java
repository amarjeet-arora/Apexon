package exception;

public class AccountTransactionException extends CustomException{

	public AccountTransactionException() {
		super();
		// TODO Auto-generated constructor stub
	}

	public AccountTransactionException(String message, Throwable cause) {
		super(message, cause);
		// TODO Auto-generated constructor stub
	}

	public AccountTransactionException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}

	public AccountTransactionException(Throwable cause) {
		super(cause);
		// TODO Auto-generated constructor stub
	}

}
