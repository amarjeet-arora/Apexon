package collectiondemos;

 import java.util.TreeSet;

public class TreeSetDemo {
	
	
	public static void main(String[] args) {
		TreeSet<Employee> al= new TreeSet<Employee>();
		al.add(new Employee("a101","John"));
		al.add(new Employee("a12","Sito"));
		 
		al.add(new Employee("a131","Aman"));
		al.add(new Employee("a141","Ravi"));
		al.add(new Employee("a141","Ravi"));
		for(Employee e1:al)
		System.out.println(e1);
	}

}
