package collectiondemos;

import java.util.Collections;
import java.util.HashSet;
import java.util.LinkedList;

public class HashSetDemo {
	public static void main(String[] args) {
		HashSet<Employee> al= new HashSet<Employee>();
		al.add(new Employee("a101","John"));
		al.add(new Employee("a12","Sito"));
		 
		al.add(new Employee("a131","Aman"));
		al.add(new Employee("a141","Ravi"));
		al.add(new Employee("a141","Ravi"));
		for(Employee e1:al)
		System.out.println(e1);
		
	 
	}

}
