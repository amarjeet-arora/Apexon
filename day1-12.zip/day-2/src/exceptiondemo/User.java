package exceptiondemo;

public class User {
	
	private String uname;
	private String password;
	public User(String uname, String password) {
		super();
		this.uname = uname;
		this.password = password;
	}
	public User() {
		super();
		 
	}
	

}
