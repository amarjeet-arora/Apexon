package com.interfacedemo;

public interface SilverClassBooking {
	
	public void checkIn();
	public void checkOut();

}
