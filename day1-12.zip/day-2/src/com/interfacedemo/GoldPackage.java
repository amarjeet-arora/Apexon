package com.interfacedemo;

public interface GoldPackage extends SilverClassBooking{
	
	public void latecheckOut();
	
	public void bfastIncluded();

}
