package com.hs.service;

import com.hs.restaurant.Restaurant;

public class RoomService {
	
	private Restaurant restaurant;

	
	
	public String placeOrder(String dishName) {
		return restaurant.prepareOrder(dishName);
	}

	public Restaurant getRestaurant() {
		return restaurant;
	}

	public void setRestaurant(Restaurant restaurant) {
		this.restaurant = restaurant;
	}
	

}
