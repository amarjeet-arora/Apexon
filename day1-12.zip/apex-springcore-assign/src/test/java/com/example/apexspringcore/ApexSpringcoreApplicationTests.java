package com.example.apexspringcore;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ApexSpringcoreApplicationTests {

	@Test
	void contextLoads() {
	}

}
