package com.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Service;
import com.model.InterestCalculator;

@Service(value = "service")
public class BankService {
	
	
	
	@Autowired
	@Qualifier(value = "fda")
	private InterestCalculator calculator;

	public InterestCalculator getCalculator() {
		return calculator;
	}

	public void setCalculator(InterestCalculator calculator) {
		this.calculator = calculator;
	}
	
	public double service(double amount) {
		return calculator.calculate(amount);
	}
	public void init() {
		System.out.println("called post Service bean");
	}
	public void destroy() {
		System.out.println("Called before destroy");
	}

}
