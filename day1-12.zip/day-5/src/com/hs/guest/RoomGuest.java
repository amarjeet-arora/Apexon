package com.hs.guest;

import com.factory.RestaurantFactory;
import com.hs.restaurant.AmericanRestaurant;
import com.hs.restaurant.ItalianRestaurant;
import com.hs.service.RoomService;

public class RoomGuest {

	public static void main(String[] args) {
	 
		RoomService roomService= new RoomService(RestaurantFactory.create('I'));
		
		System.out.println(roomService.placeOrder("burger"));
	}

}
