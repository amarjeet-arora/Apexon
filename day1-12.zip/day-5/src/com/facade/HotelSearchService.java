package com.facade;

import java.util.LinkedList;
import java.util.List;

public class HotelSearchService {
	private List<Room> rooms;

	public HotelSearchService() {
		rooms = new LinkedList<Room>();
	}

	public void addRoom(Room room) {
		rooms.add(room);
	}

	public List<Room> search(RoomType rt) {

		List<Room> sr = new LinkedList<Room>();

		for (Room r : rooms)
			if (r.isVacant() && r.getType().equals(rt))
				sr.add(r);
		return sr;
	}

	public void reserve(int roomNo) {
		for (Room r : rooms) {
			if (r.getRoomNo() == roomNo) {
				r.setVacant(false);
				return;
			}
		}
	}
}
