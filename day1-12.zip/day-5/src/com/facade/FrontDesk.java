package com.facade;

public class FrontDesk {
	public static void main(String[] args) {
		
		HotelFacade facade= new HotelFacade();
		facade.showRooms();
		System.out.println(facade.reserveRoom(RoomType.SINGLE));
		System.out.println(facade.reserveRoom(RoomType.SINGLE));
		System.out.println(facade.reserveRoom(RoomType.DOUBLE));
		System.out.println(facade.reserveRoom(RoomType.DOUBLE));
		System.out.println(facade.reserveRoom(RoomType.DOUBLE));
		facade.showRooms();
	}

}
