package deecorator;

public class BillingCounter {
	
	public static void main(String[] args) {
		
		Sale sale= new Sale(15, 2000);
		System.out.println("without discount " + sale.getTotal());
		//sale= new DiscountDecorator(sale);
		System.out.println("with 5 % discount " + sale.getTotal());
		
		sale= new PrivMemDiscount(sale);
		System.out.println("with 10$  discount " + sale.getTotal());
	}
	

}
