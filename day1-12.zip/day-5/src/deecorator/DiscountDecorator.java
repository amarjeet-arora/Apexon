package deecorator;

public class DiscountDecorator extends SaleDecorator{
	
	Sale sale;

	public DiscountDecorator(Sale sale) {
		super();
		this.sale = sale;
	}

	@Override
	public double getTotal() {
		 
		return sale.getTotal()-(5.0/100.0*sale.getTotal());
	}

	public int getNop() {
		return sale.getNnop();
	}
}
