package com.demoapp;

import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectOutputStream;

public class Userserial {

	public static void main(String[] args) throws IOException {
		 
		Users users= new Users("sam", "sam@mail.com","Manager", "florida");
		
		System.out.println(users);
		
		FileOutputStream fos= new FileOutputStream("userdata.txt");
		
		ObjectOutputStream oos= new ObjectOutputStream(fos);
		
		oos.writeObject(users);
		
		System.out.println("user added");
		

	}
	

}
