package com.demoapp;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.util.ArrayList;

public class JukeBox {
	ArrayList<Songs> al= new ArrayList<Songs>();
	
	public static void main(String[] args) {
		new JukeBox().printData();
	}
	public void printData() {
		loadSongs();
		for(Songs users: al)
		System.out.println(users);
	}
	private void loadSongs() {
		try {
			File file= new File("songs.txt");
			BufferedReader br= new BufferedReader(new FileReader(file));
			String line=null;
			while((line=br.readLine()) != null) {
				addSongs(line);
			}
			
			
		}catch (Exception e) {}
	}
	private void addSongs(String parseData) {
		
		String [] tokens =parseData.split("/");
		Songs users= new Songs(tokens[0], tokens[1], tokens[2], tokens[3]);
		al.add(users);
	}

}
