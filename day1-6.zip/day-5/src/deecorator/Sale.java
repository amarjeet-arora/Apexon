package deecorator;

public class Sale {
	
	private int nnop;
	private double saleamount;
	
	public double getTotal() {
		return saleamount;
	}

	public int getNnop() {
		return nnop;
	}

	public void setNnop(int nnop) {
		this.nnop = nnop;
	}

	public Sale() {
		super();
		// TODO Auto-generated constructor stub
	}

	public Sale(int nnop, double saleamount) {
		super();
		this.nnop = nnop;
		this.saleamount = saleamount;
	}

	public double getSaleamount() {
		return saleamount;
	}

	public void setSaleamount(double saleamount) {
		this.saleamount = saleamount;
	}

}
