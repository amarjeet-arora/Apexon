package deecorator;

public abstract class SaleDecorator extends Sale {
	
	public abstract double getTotal();

}
