package com.factory;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.Properties;

import com.hs.restaurant.AmericanRestaurant;
import com.hs.restaurant.ItalianRestaurant;
import com.hs.restaurant.Restaurant;

public class RestaurantFactory {
	private static Properties p = new Properties();

	static {

		try {
			p.load(new FileInputStream("factory.properties"));
		} catch (Exception e) {
		}

	}

	public static Restaurant create(char type) {
		try {
			Class c = Class.forName(p.getProperty("" + type));
			return (Restaurant) c.newInstance();

		} catch (Exception e) {

		}
		return null;
	}

}
