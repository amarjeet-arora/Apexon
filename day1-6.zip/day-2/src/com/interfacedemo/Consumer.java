package com.interfacedemo;

public class Consumer implements GoldPackage{

	@Override
	public void checkIn() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void checkOut() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void latecheckOut() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void bfastIncluded() {
		// TODO Auto-generated method stub
		
	}

}
