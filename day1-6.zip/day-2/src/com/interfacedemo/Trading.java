package com.interfacedemo;

public interface Trading {
	
	 
	public void openTradingAccount();
	public void purchaseShares();
	 
	 

}
