package com.interfacedemo;

public class CustomeMain {

	public static void main(String[] args) {
		 
		Customer customer= new Customer();
		
		customer.topupCoverage();
	}

}
