package sam;

@FunctionalInterface
public interface SamDemo {
	public void doSomeWork();
	//public void doSomeWork2();

	
}
