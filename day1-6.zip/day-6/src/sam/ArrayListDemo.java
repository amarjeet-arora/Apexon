package sam;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;

public class ArrayListDemo {
	
	public static void main(String[] args) {
		
		
		ArrayList<Employee> al= new ArrayList<Employee>();
		al.add(new Employee("a101","John"));
		al.add(new Employee("a12","Sito"));
		al.add(new Employee("a131","Aman"));
		al.add(new Employee("a141","Ravi"));
		al.add(1,new Employee("a141","Ravi"));
		
		Collections.sort(al, new Comparator<Employee>() {
			
            @Override
			public int compare(Employee o1, Employee o2) {
 				return o1.getEmpName().compareTo(o2.getEmpName());
			}
		});
		System.out.println("sort using standard way");
		for(Employee e1: al) {
			System.out.println(e1);
		}
		
		//lambda Way
		System.out.println("------------Lambda Way---------");
		
		Collections.sort(al,(Employee o1, Employee o2) ->o1.getEmpName().compareTo(o2.getEmpName()));
		for(Employee e1: al) {
			System.out.println(e1);
		}
		
		}

}
