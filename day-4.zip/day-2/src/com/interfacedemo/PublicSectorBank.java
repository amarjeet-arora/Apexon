package com.interfacedemo;

public class PublicSectorBank implements Banking,Insurance{

	@Override
	public void checkBalance() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void withdraw() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void deposit() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void takePolicy() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void claimPolicy() {
		// TODO Auto-generated method stub
		
	}

	

}
