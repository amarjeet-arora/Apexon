package com.hs.restaurant;

public interface Restaurant {
	
	public String prepareOrder(String food);

}
