package collectiondemos;

import java.util.ArrayList;
import java.util.Collections;
import java.util.LinkedList;

public class LInkedListDemo {
	
	public static void main(String[] args) {
		
		
		LinkedList<Employee> al= new LinkedList<Employee>();
		al.add(new Employee("a101","John"));
		al.add(new Employee("a12","Sito"));
		al.addLast(new Employee("a171","SAM"));
		al.add(new Employee("a131","Aman"));
		al.add(new Employee("a141","Ravi"));
		al.addFirst(new Employee("a141","Ravi"));
		System.out.println("Original ......");
		for(Employee e1:al)
		System.out.println(e1);
		
	 al.removeFirst();
		System.out.println("Size of List  "+ al.size());
		al.remove(1);
		System.out.println("After Removal .....");
		for(Employee e1:al)
			System.out.println(e1);
		
		
		System.out.println("---------After Sorting---------");
		Collections.sort(al,new NameComparator());
		for(Employee e1:al)
			System.out.println(e1);
		
		
		
		
	}

}
