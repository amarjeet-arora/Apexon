package com.service;

import javax.annotation.PostConstruct;
import javax.annotation.PreDestroy;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Service;
import com.model.InterestCalculator;

 
public class BankService {
	
	
	
	 
	private InterestCalculator calculator;

	public InterestCalculator getCalculator() {
		return calculator;
	}

	public void setCalculator(InterestCalculator calculator) {
		this.calculator = calculator;
	}
	
	public double service(double amount) {
		return calculator.calculate(amount);
	}
	
	

	public BankService(InterestCalculator calculator) {
		super();
		this.calculator = calculator;
	}
	
	

}
