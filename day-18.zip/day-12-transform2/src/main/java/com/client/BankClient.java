package com.client;

 
import org.springframework.context.annotation.AnnotationConfigApplicationContext;
 
import com.service.BankService;

public class BankClient {

	public static void main(String[] args) {
		// ConfigurableApplicationContext ctx= new ClassPathXmlApplicationContext("beans.xml");
		 
		AnnotationConfigApplicationContext ctx= new AnnotationConfigApplicationContext(AppConfig.class);
		 BankService bs=(BankService)ctx.getBean("service");
		 
//		 
	 System.out.println(bs.service(3345));
	 
	 
	 
	 
	ctx.close();

	}

}
