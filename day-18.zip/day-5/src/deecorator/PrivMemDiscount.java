package deecorator;

public class PrivMemDiscount  extends SaleDecorator{
	
	
	Sale sale;

	public PrivMemDiscount(Sale sale) {
		super();
		this.sale = sale;
	}

	@Override
	public double getTotal() {
		if(sale.getNnop()>10)
			return sale.getTotal()-10.0;
		return sale.getTotal();
	}
	public int getNop() {
		return sale.getNnop();
	}

}
