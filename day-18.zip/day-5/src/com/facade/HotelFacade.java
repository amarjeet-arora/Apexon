package com.facade;

import java.util.List;

public class HotelFacade {
	
	HotelSearchService service;
	
	public HotelFacade() {
		service= new HotelSearchService();
		for(int i=0;i<20;i++)
			if(i%2==0)
				service.addRoom(new Room(i+1, RoomType.SINGLE, true));
			else 
		        service.addRoom(new Room(i+1, RoomType.DOUBLE, true));
	}

	public String reserveRoom(RoomType rt) {
		List<Room> r= service.search(rt);
		if(r.size() > 0) {
			service.reserve(r.get(0).getRoomNo());
			
			return "success";
		}else {
			return "failure";
		}
	}
	public void showRooms() {
		System.out.println(service.search(RoomType.SINGLE));
		System.out.println(service.search(RoomType.DOUBLE));
	}
}
