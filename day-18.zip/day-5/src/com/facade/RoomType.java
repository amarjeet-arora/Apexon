package com.facade;

public enum RoomType {

	SINGLE,DOUBLE
}
