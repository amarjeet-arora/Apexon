package com.example.day14apexmvc;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Day14ApexMvcApplicationTests {

	@Test
	void contextLoads() {
	}

}
