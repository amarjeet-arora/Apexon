package com.accountdemo;

import java.util.List;

public interface AccountDAO {
	public void createAccount(Account account);
	public List<Account> getAllAccounts();
	public Account getAccount(String account);
	public void updateAccount(Account account);

}
