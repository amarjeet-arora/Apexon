package com.accountdemo;

public class Account {
	private String accNo;
	private String accountOwnner;
	private double balance;
	public String getAccNo() {
		return accNo;
	}
	public void setAccNo(String accNo) {
		this.accNo = accNo;
	}
	public String getAccountOwnner() {
		return accountOwnner;
	}
	public void setAccountOwnner(String accountOwnner) {
		this.accountOwnner = accountOwnner;
	}
	public double getBalance() {
		return balance;
	}
	public void setBalance(double balance) {
		this.balance = balance;
	}
	public Account(String accNo, String accountOwnner, double balance) {
		super();
		this.accNo = accNo;
		this.accountOwnner = accountOwnner;
		this.balance = balance;
	}
	public Account() {
		super();
		 
	}
	public Account(Account acc) {
		this.accNo= new String(acc.getAccNo());
		this.accountOwnner= new String(acc.getAccountOwnner());
		this.balance= acc.getBalance();
	}
	@Override
	public String toString() {
		return "Account [accNo=" + accNo + ", accountOwnner=" + accountOwnner + ", balance=" + balance + "]";
	}
	
	

}
