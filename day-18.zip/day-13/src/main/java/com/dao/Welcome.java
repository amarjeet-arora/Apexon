package com.dao;

public interface Welcome {
	
	public String sayWelcome(String name);
	public void sayHello();

}
