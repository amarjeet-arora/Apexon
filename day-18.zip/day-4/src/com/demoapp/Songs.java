package com.demoapp;

public class Songs {
	
	private String sName;
	private String aName;
	private String rating;
	private String language;
	public String getsName() {
		return sName;
	}
	public void setsName(String sName) {
		this.sName = sName;
	}
	public String getaName() {
		return aName;
	}
	public void setaName(String aName) {
		this.aName = aName;
	}
	public String getRating() {
		return rating;
	}
	public void setRating(String rating) {
		this.rating = rating;
	}
	public String getLanguage() {
		return language;
	}
	public void setLanguage(String language) {
		this.language = language;
	}
	@Override
	public String toString() {
		return "Songs [sName=" + sName + ", aName=" + aName + ", rating=" + rating + ", language=" + language + "]";
	}
	public Songs(String sName, String aName, String rating, String language) {
		super();
		this.sName = sName;
		this.aName = aName;
		this.rating = rating;
		this.language = language;
	}
	public Songs() {
		super();
		// TODO Auto-generated constructor stub
	}
	
	
	
	 

}
