package com.demoapp;

import java.util.Comparator;

public class NameComp implements Comparator<Users>{

	@Override
	public int compare(Users o1, Users o2) {
		 
		return o1.getuName().compareTo(o2.getuName());
	}

}
