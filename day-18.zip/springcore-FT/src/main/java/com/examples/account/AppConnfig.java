package com.examples.account;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;

import com.examples.account.repository.AccountRepository;
import com.examples.account.repository.InMemoryAccountRepository;
import com.examples.account.service.TransferService;
import com.examples.account.service.TransferServiceImpl;

@Configuration
@ComponentScan("com")
public class AppConnfig {

	@Bean
	public AccountRepository accountRepository() {
		return new InMemoryAccountRepository();
	}
	@Bean
	public TransferService transferService() {
		return new TransferServiceImpl(accountRepository());
	}
	
}
