package com.example.day14apexmvc;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.autoconfigure.domain.EntityScan;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;

import springfox.documentation.swagger2.annotations.EnableSwagger2;

@SpringBootApplication
@ComponentScan("com")
@EntityScan("com.entity")
@EnableJpaRepositories("com.dal")
@EnableSwagger2
public class Day14ApexMvcApplication {

	public static void main(String[] args) {
		SpringApplication.run(Day14ApexMvcApplication.class, args);
	}

}
