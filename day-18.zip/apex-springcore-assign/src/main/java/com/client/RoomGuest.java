package com.client;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.hs.service.RoomService;
 
public class RoomGuest {

	public static void main(String[] args) {
		 ApplicationContext ctx= new ClassPathXmlApplicationContext("beans.xml");
		 
		 RoomService rs=(RoomService)ctx.getBean("service");
		 
		 System.out.println(rs.placeOrder("Fries"));

	}

}
