package com.example.apexspringcore;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ApexSpringcoreApplication {

	public static void main(String[] args) {
		SpringApplication.run(ApexSpringcoreApplication.class, args);
	}

}
