package annotationdemo;




@JavaFileInfo
public class DemoClass {
	
	@JavaFileInfo(author = "method-level")
	public String sayHello() {
		return null;
	}
	
	

}
