package com.dao;

import java.util.List;

import com.entity.Project;

public interface ProjectDAO {
	
	public void addProject(Project project);

	public List<Project> lodPro();
	
	public boolean findProject(int pid);
	
	public boolean deleteProject(int pid);
	
	public void updateProject(int pid,String name);
	
	public Project findProjectCustom(String pname,String loc);
}
