package com.dao;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.dal.ProjectDAL;
import com.entity.Project;
@Service
public class ProjectDaoIMPL implements ProjectDAO{
	
	@Autowired
	private ProjectDAL dal;

	@Override
	public void addProject(Project project) {
	dal.save(project); 
		
	}
	public List<Project> lodPro(){
		return (List) dal.findAll();
	}
	@Override
	public boolean findProject(int pid) {
	 
	Optional<Project> data=	dal.findById(pid);
	if(data.isPresent()) {
		return true;
	}
		return false;
	}
	@Override
	public boolean deleteProject(int pid) {
		 
		Optional<Project> data=	dal.findById(pid);
		if(data.isPresent()) {
			dal.deleteById(pid);
			return true;
		}
			return false;
		}
	@Override
	public void updateProject(int pid, String name) {
		dal.updateProject(name, pid);
		
	}
	@Override
	public Project findProjectCustom(String pname, String loc) {
		// TODO Auto-generated method stub
		return dal.findProjectCustom(pname, loc);
	}

}
