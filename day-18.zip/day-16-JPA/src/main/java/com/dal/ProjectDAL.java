package com.dal;

import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.entity.Project;
@Repository
public interface ProjectDAL extends CrudRepository<Project, Integer>{
	
	
	@Transactional
	@Modifying
	@Query("update Project p set p.projectName=?1 where p.projectId=?2")
	public int updateProject(String name,int pId);
	
	
	@Query("select p from Project p where p.projectName=?1 and p.projectLocation=?2 ")
	public Project findProjectCustom(String pname,String loc);

}
