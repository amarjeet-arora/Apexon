package com.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.dao.ProjectDAO;
import com.entity.Project;

@RestController
@RequestMapping("/promain")
public class ProController {
    @Autowired
	private ProjectDAO dao;
	
	@PostMapping("/addpro")
	public String addProject(@RequestBody Project project) {
		dao.addProject(project);
		
		return "user added";
		
		
	}
	@GetMapping("/loadpro")
	public List<Project> loadall(){
		return dao.lodPro();
	}
	@GetMapping("/loadpro/{pname}/{loc}")
	public Project getPro(@PathVariable String pname,@PathVariable String loc) {
		return dao.findProjectCustom(pname, loc);
		
	}
	
}
