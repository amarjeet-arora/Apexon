package collectiondemos;

import java.util.ArrayList;
import java.util.Collections;

public class ArrayListDemo {
	
	public static void main(String[] args) {
		
		
		ArrayList<Employee> al= new ArrayList<Employee>();
		al.add(new Employee("a101","John"));
		al.add(new Employee("a12","Sito"));
		al.add(new Employee("a131","Aman"));
		al.add(new Employee("a141","Ravi"));
		al.add(1,new Employee("a141","Ravi"));
		System.out.println("Original ......");
		for(Employee e1:al)
		System.out.println(e1);
		
		System.out.println(al.get(0));
		System.out.println("Size of List  "+ al.size());
		al.remove(1);
		System.out.println("After Removal .....");
		for(Employee e1:al)
			System.out.println(e1);
		
		
		System.out.println("---------After Sorting---------");
		Collections.sort(al,new NameComparator());
		for(Employee e1:al)
			System.out.println(e1);
		
		
		
		
	}

}
