package collectiondemos;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;

public class HashMapDemo {

	public static void main(String[] args) {
		 
		HashMap<Integer, List<Employee>> hm= new HashMap<Integer, List<Employee>>();
		
		ArrayList<Employee> al= new ArrayList<Employee>();
		al.add(new Employee("a101","John"));
		al.add(new Employee("a12","Sito"));
		al.add(new Employee("a131","Aman"));
		al.add(new Employee("a141","Ravi"));
		al.add(new Employee("a141","Ravi"));
		
		hm.put(1209, al);
		
		System.out.println(hm);
		 
		
		

	}

}
