package com.interfacedemo;

public class PrivateSectorBank implements Banking ,Trading{

	@Override
	public void checkBalance() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void withdraw() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void deposit() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void openTradingAccount() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void purchaseShares() {
		// TODO Auto-generated method stub
		
	}

	

}
