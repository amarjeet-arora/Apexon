package exceptiondemo;

import java.io.FileNotFoundException;
import java.io.FileOutputStream;

public class UserDaoImpl implements UserDao{

	@Override
	public void addUser(User user) throws DataAccessException {
		 
		 
			try {
				FileOutputStream fout= new FileOutputStream("c::\newfile/data");
			} catch (FileNotFoundException e) {
				throw new DataAccessException("something went wrong....try after sometime", e);
			 
				 
			}
	 
			 
			 
		
	}

}
