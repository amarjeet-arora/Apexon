package exceptiondemo;

import java.io.FileNotFoundException;

public interface UserDao {
	
	public void addUser(User user) throws DataAccessException;

}
