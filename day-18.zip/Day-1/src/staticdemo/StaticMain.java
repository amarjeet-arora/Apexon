package staticdemo;

public class StaticMain {

	public static void main(String[] args) {
		StaticApp sa= new StaticApp();
		sa.showStan();
		StaticApp.show();

	}
	

}
