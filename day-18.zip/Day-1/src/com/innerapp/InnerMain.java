package com.innerapp;

public class InnerMain {

	public static void main(String[] args) {
		 InnerDemo demo= new InnerDemo();
		 demo.printEven();

	}

}
