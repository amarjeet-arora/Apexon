package com.service;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.dao.UserDao;
import com.model.User;

@Service
public class UserService {
	@Autowired
	private UserDao userDao;
	
	ArrayList<User> al= new ArrayList<User>();
	
	public boolean loginValidate(User user) {
		if(user.getUname().equals("admin") && user.getPass().equals("manager")) {
			
			return true;
		}
		return false;
	}
	@Transactional
	public void addUser(User user) {
		 userDao.addUser(user);
		 if(user.getCity().equals("london")) {
			 throw new RuntimeException("something went wrong");
		 }
		 User user2= new User("sam", "sam@123", "sam@email.com", "mumbai");
		 userDao.addUser(user2);
	}
	
public List<User> loadAll(){
	
	return userDao.getAllUsers();
}

public boolean findUser(String name) {
	for (User user: al) {
		if(user.getUname().equals(name)) {
			return true;
		}
	}
	return false;
}
public boolean deleteUser(String name) {
	for (User user: al) {
		if(user.getUname().equals(name)) {
			al.remove(user);
			return true;
		}
	}
	return false;
}

public boolean updateUser(String uname,User user) {
	
	
	
	return true;
}


}
